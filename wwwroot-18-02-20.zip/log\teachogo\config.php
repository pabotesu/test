<?php
	$host = "127.0.0.1:53105";
	$username = "azure";
	$password = "6#vWHD_$";
	$dbname = "teacherdb";
	$studentdb = "localdb";
?>