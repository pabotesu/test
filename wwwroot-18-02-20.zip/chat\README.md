# javascript-chat-milkcocoa-demo
You can make chat application about 5 minute.

## Description
It's a demo.
You can make chat application about 5 minute.

![1dz4ip.gif (601.4 kB)](https://img.esa.io/uploads/production/attachments/461/2016/11/11/10749/7abda302-0686-4063-95de-878edf7fdebb.gif)

Please read explanation of [Qiita](http://qiita.com/HiromuTsuruta/items/a1e19c5d9c62cb686d1f)

## Requirement
- If you wanna use RealTimeDatabase of [MilkCocoa](https://mlkcca.com/), you have to signup for MilkCocoa that is free.

## Usage

1. Signup [MilkCocoa](https://mlkcca.com/)
2. Get your id

## SetUp

Must read [MilkCocoa](https://mlkcca.com/)
